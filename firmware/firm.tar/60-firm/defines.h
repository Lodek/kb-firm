#define INPUTS_LEN 8
#define OUTPUTS_LEN 10

#define HOLD_DELAY 150
#define RETAP_DELAY 150

//csv notation
#define OUTPUT_PINS 10,16,14,15,18,19,20,21,0,1
#define INPUT_PINS  9,8,7,6,5,4,3,2
